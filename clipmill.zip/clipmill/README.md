# Clipmill

AI clipping app for YouTubers. Stage 1: website design.
